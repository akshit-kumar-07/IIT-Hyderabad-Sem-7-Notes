\# BankDocs Backend (FastAPI)



\## 1) Setup

python -m venv .venv

source .venv/bin/activate

pip install -r requirements.txt

cp .env.example .env

\# edit .env as needed



\## 2) Run

uvicorn main:app --reload --port 8080



Health check:

GET http://localhost:8080/api/health



\## 3) Frontend integration (React side)

POST multipart/form-data to /api/extract with:

\- payload\_json: JSON string matching ExtractIn (see below)

\- pdf: (optional) uploaded PDF file



Headers:

\- X-API-KEY: <BANKDOCS\_BACKEND\_KEY>  (if configured)



Example payload\_json:

{

&nbsp; "form": "10-k",

&nbsp; "prompts": \[

&nbsp;   "Extract company name, CIK, fiscal year, and auditor name.",

&nbsp;   "Pull MD\&A summary and key metrics (revenue, net income)."

&nbsp; ],

&nbsp; "hadLibraryPrompts": true

}



ONLY custom selection example:

{

&nbsp; "form": "10-k",

&nbsp; "prompts": \["Find revenue trend", "Summarize risk changes"],

&nbsp; "config": { "model": "gpt-4o-mini", "system": "Custom system guidance" },

&nbsp; "fieldNames": \["Company Name", "Revenue", "Net Income"],

&nbsp; "promptSetName": "Risk \& Revenue Pull",

&nbsp; "hadLibraryPrompts": false

}



\## 4) Notes

\- If ENABLE\_LLM=false or OPENAI\_API\_KEY is empty, the backend returns deterministic mock data.

\- If ENABLE\_LLM=true and OPENAI\_API\_KEY is set, the backend will call OpenAI and still fallback to mock on errors.

\- PDF text extraction is disabled by default; enable by setting PDF\_TEXT\_EXTRACTION=true (requires pdfminer.six).



