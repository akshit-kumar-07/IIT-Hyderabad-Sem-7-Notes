import os
import io
import json
import time
import uuid
from typing import List, Optional, Literal, Dict, Any

from fastapi import FastAPI, File, UploadFile, Form, Depends, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, validator
from starlette.requests import Request

# ---------- Optional: lightweight PDF text extraction ----------
PDF_TEXT_EXTRACTION = os.getenv("PDF_TEXT_EXTRACTION", "false").lower() == "true"
if PDF_TEXT_EXTRACTION:
    try:
        from pdfminer.high_level import extract_text as pdf_extract_text
    except Exception:
        PDF_TEXT_EXTRACTION = False  # auto-disable if not available

# ---------- LLM provider toggles ----------
ENABLE_LLM = os.getenv("ENABLE_LLM", "false").lower() == "true"
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

# ---------- Backend access protection (optional) ----------
BACKEND_API_KEY = os.getenv("BANKDOCS_BACKEND_KEY")  # if set, required via X-API-KEY

# ---------- Basic rate limiting (very light) ----------
RATE_LIMIT_RPM = int(os.getenv("RATE_LIMIT_RPM", "120"))  # requests per minute per IP
rate_bucket: Dict[str, List[float]] = {}

# ---------- Default per-form configs (mirror your frontend) ----------
DEFAULT_CONFIGS = {
    "10-k":  {"model": "gpt-4o-mini", "system": "Use 10-K tuned system with SEC heuristics."},
    "10-q":  {"model": "gpt-4o-mini", "system": "Use 10-Q tuned system with quarterly deltas."},
    "1040":  {"model": "gpt-4o-mini", "system": "US 1040 extraction defaults; mask PII like SSN."},
    "1099":  {"model": "gpt-4o-mini", "system": "1099 box mapping + payer/recipient normalization."},
    "w2":    {"model": "gpt-4o-mini", "system": "W-2 extraction defaults; wages/tax withheld focus."},
}

# ---------- Allowed models (advertise to the UI if you like) ----------
ALLOWED_MODELS = [
    "gpt-4o-mini",
    "claude-3-5-sonnet",
    "llama-3.1-70b-instruct"
]

# ---------- Pydantic models ----------
class Coord(BaseModel):
    page: int = 1
    bbox: List[float] = Field(..., min_items=4, max_items=4, description="[x, y, w, h] normalized 0..1")

class FieldItem(BaseModel):
    id: str
    label: str
    value: str
    coord: Optional[Coord] = None

class ExtractResult(BaseModel):
    fields: List[FieldItem]

class ConfigIn(BaseModel):
    model: Optional[str] = None
    system: Optional[str] = None

class ExtractIn(BaseModel):
    form: str
    prompts: List[str]
    # if ONLY custom prompts are selected, frontend may include:
    config: Optional[ConfigIn] = None
    fieldNames: Optional[List[str]] = None
    promptSetName: Optional[str] = None
    # optional hint from UI: whether any library prompts were used
    hadLibraryPrompts: Optional[bool] = None

    @validator("form")
    def check_form(cls, v):
        v = v.lower().strip()
        if v not in DEFAULT_CONFIGS:
            raise ValueError(f"Unsupported form: {v}")
        return v

# ---------- Helpers ----------
def require_backend_key(x_api_key: Optional[str] = Header(None)):
    if BACKEND_API_KEY and x_api_key != BACKEND_API_KEY:
        raise HTTPException(status_code=401, detail="Missing or invalid X-API-KEY")
    return True

def rate_limit(request: Request):
    """Very naive sliding window by remote address."""
    ip = request.client.host if request.client else "unknown"
    now = time.time()
    bucket = rate_bucket.setdefault(ip, [])
    # drop old entries (older than 60s)
    rate_bucket[ip] = [t for t in bucket if now - t < 60.0]
    if len(rate_bucket[ip]) >= RATE_LIMIT_RPM:
        raise HTTPException(status_code=429, detail="Rate limit exceeded")
    rate_bucket[ip].append(now)

def gen_uid(prefix="field"):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

def to_fields_from_names(names: List[str]) -> List[FieldItem]:
    out = []
    for i, name in enumerate(names):
        fid = f"{name.lower().strip().replace(' ', '_').replace('/', '_')}_{i}"
        out.append(FieldItem(
            id=fid,
            label=name,
            value=f"<<sample {name}>>",
            coord=Coord(page=1, bbox=[0.1 + i*0.04, 0.2 + i*0.05, 0.22, 0.035])
        ))
    return out

# ---------- Mock extraction (deterministic) ----------
def mock_extract(payload: ExtractIn, pdf_text: Optional[str]) -> ExtractResult:
    # If ONLY custom prompts (frontend will omit library prompts and set fieldNames)
    if payload.fieldNames:
        return ExtractResult(fields=to_fields_from_names(payload.fieldNames))

    # Otherwise return a small constant demo set
    return ExtractResult(fields=[
        FieldItem(
            id="company_name",
            label="Company Name",
            value="Acme Corp",
            coord=Coord(page=1, bbox=[0.12, 0.18, 0.24, 0.035])
        ),
        FieldItem(
            id="fiscal_year",
            label="Fiscal Year",
            value="FY 2024",
            coord=Coord(page=1, bbox=[0.12, 0.23, 0.14, 0.03])
        ),
        FieldItem(
            id="auditor",
            label="Auditor",
            value="Example & Co. LLP",
            coord=Coord(page=1, bbox=[0.58, 0.82, 0.28, 0.04])
        ),
        FieldItem(
            id="revenue",
            label="Revenue",
            value="$ 1,234,567",
            coord=Coord(page=1, bbox=[0.65, 0.42, 0.18, 0.032])
        )
    ])

# ---------- Optional: OpenAI LLM extraction ----------
def extract_with_openai(payload: ExtractIn, pdf_text: Optional[str]) -> ExtractResult:
    """
    Very simple implementation illustrating how you'd call OpenAI.
    It uses a single prompt that aggregates all user prompts.
    In production you'd craft a better system/user/assistant structure
    and possibly few-shot examples and schema-constrained output.
    """
    import openai  # requires openai>=1.40.0
    client = openai.OpenAI(api_key=OPENAI_API_KEY)

    # Decide config:
    if payload.hadLibraryPrompts:
        model = DEFAULT_CONFIGS[payload.form]["model"]
        system = DEFAULT_CONFIGS[payload.form]["system"]
    else:
        model = (payload.config.model if payload.config and payload.config.model else "gpt-4o-mini")
        system = (payload.config.system if payload.config and payload.config.system else "")

    # Build a unified prompt:
    prompt_lines = []
    prompt_lines.append(f"Form: {payload.form}")
    if payload.promptSetName:
        prompt_lines.append(f"Prompt Set: {payload.promptSetName}")
    if payload.prompts:
        prompt_lines.append("Prompts:")
        for p in payload.prompts:
            prompt_lines.append(f"- {p}")
    if payload.fieldNames:
        prompt_lines.append("Requested Field Names:")
        for n in payload.fieldNames:
            prompt_lines.append(f"- {n}")
    if pdf_text:
        prompt_lines.append("\nDocument Text (truncated):")
        prompt_lines.append(pdf_text[:6000])  # keep token usage sane

    user_prompt = "\n".join(prompt_lines)

    # Ask the model to output a JSON array of fields
    system_instructions = (
        (system + "\n\n") if system else ""
    ) + "You are an information extraction assistant. Return a JSON object with a 'fields' array. Each item has {id, label, value}."

    resp = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system_instructions},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.1,
    )

    text = resp.choices[0].message.content or "{}"
    try:
        obj = json.loads(text)
    except Exception:
        # If the model didn't return JSON, fallback to mock shape
        return mock_extract(payload, pdf_text)

    fields_raw = obj.get("fields") or []
    fields: List[FieldItem] = []
    for i, f in enumerate(fields_raw):
        try:
            fields.append(FieldItem(
                id=f.get("id") or gen_uid("field"),
                label=f.get("label") or f"Field {i+1}",
                value=str(f.get("value", "")),
                coord=None  # optional: ask model for coords if you have a page layout step
            ))
        except Exception:
            continue

    if not fields:
        return mock_extract(payload, pdf_text)
    return ExtractResult(fields=fields)

# ---------- FastAPI app ----------
app = FastAPI(title="BankDocs Backend", version="1.0.0")

# CORS
ALLOWED_ORIGINS = os.getenv("CORS_ALLOW_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in ALLOWED_ORIGINS],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/health")
def health() -> Dict[str, Any]:
    return {
        "status": "ok",
        "llm_enabled": ENABLE_LLM,
        "pdf_text_extraction": PDF_TEXT_EXTRACTION,
        "allowed_models": ALLOWED_MODELS,
    }

@app.get("/api/config")
def config(_: bool = Depends(require_backend_key)) -> Dict[str, Any]:
    return {
        "defaults": DEFAULT_CONFIGS,
        "allowed_models": ALLOWED_MODELS,
    }

@app.post("/api/extract", response_model=ExtractResult)
async def extract(
    request: Request,
    _: bool = Depends(require_backend_key),
    payload_json: str = Form(..., description="JSON string matching ExtractIn"),
    pdf: Optional[UploadFile] = File(None, description="Optional PDF file")
):
    # rate limit
    rate_limit(request)

    # parse payload
    try:
        data = json.loads(payload_json)
        payload = ExtractIn(**data)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid payload_json: {e}")

    # read PDF text (optional)
    pdf_text: Optional[str] = None
    if pdf is not None and PDF_TEXT_EXTRACTION:
        try:
            raw = await pdf.read()
            with io.BytesIO(raw) as fh:
                # pdfminer works with paths or file objects
                pdf_text = pdf_extract_text(fh)  # type: ignore
        except Exception:
            pdf_text = None  # continue without text

    # choose path
    if ENABLE_LLM and OPENAI_API_KEY:
        try:
            result = extract_with_openai(payload, pdf_text)
        except Exception as e:
            # Never explode the UI — fall back to mock if provider fails
            result = mock_extract(payload, pdf_text)
    else:
        result = mock_extract(payload, pdf_text)

    # normalize IDs (frontend expects stable id)
    for f in result.fields:
        if not f.id:
            f.id = gen_uid("field")

    return result

# Friendly 404
@app.exception_handler(404)
async def not_found_handler(_, __):
    return JSONResponse(status_code=404, content={"detail": "Not found"})
